

In this app, I have fetched openweathermap.org API for current weather report.

Hope you'll like this sir/maim.
